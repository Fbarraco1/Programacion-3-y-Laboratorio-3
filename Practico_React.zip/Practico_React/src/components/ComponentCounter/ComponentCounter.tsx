import { useState } from "react"

export const ComponentCounter = () => {
 const[counter,SetCounter] = useState<number>(0)
    const incrementCounter = () => {
        SetCounter((prev) => prev+1)
    }
    return (
    <div>
        <h2>Valor de counter : {counter}</h2>
        <button onClick = {incrementCounter}>Incrementar</button>
    </div>
  );
}
