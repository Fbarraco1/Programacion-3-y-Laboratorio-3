import { useEffect } from "react"

export const ComponentUseEffect = () => {
  
  
  useEffect(()=>{
    
  },[]);


  return (
    <div>ComponentUseEffect</div>
  )
}
